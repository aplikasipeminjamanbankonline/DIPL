/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import briku.RiwayatPeminjaman;
import java.util.List;

/**
 *
 * @author WINDOWS 10
 */
public interface Implementasi_RiwayatPeminjaman {
    public interface Implementasi_RiwayatTour {
    public List<RiwayatPeminjaman> getAll();
}
}