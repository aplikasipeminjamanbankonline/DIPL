/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

//import DAO.DAO_RiwayatPeminjaman;
import DAO.Implementasi_RiwayatPeminjaman;
import briku.Peminjaman;
import briku.RiwayatPeminjaman;
import java.util.List;

/**
 *
 * @author WINDOWS 10
 */
/*
public class Controller_RiwayatPeminjaman {
    RiwayatPeminjaman frame;
    Implementasi_RiwayatPeminjaman implRiwayatPeminjaman;
    List<Peminjaman> lmm;

    public Controller_RiwayatPeminjaman(RiwayatPeminjaman frame) {
            this.frame = frame;
            implRiwayatPeminjaman = new DAO_RiwayatPeminjaman();
            lmm = implRiwayatPeminjaman.getAll();
    }
    
    public void isiTabel() {
        lmm = implRiwayatTour.getAll();
        Tabel_RiwayatTour mtm = new Tabel_RiwayatTour(lmm);
        frame.getTabelriwayattour().setModel(mtm);
    }
}*/
