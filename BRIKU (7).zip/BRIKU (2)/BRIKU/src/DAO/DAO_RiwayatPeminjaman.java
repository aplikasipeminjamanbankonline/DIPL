/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import briku.Peminjaman;
import briku.RiwayatPeminjaman;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTextField;

/**
 *
 * @author WINDOWS 10
 */
//public class DAO_RiwayatPeminjaman implements Implementasi_RiwayatPeminjaman {
    //Connection connection;
    //final String insert = "INSERT INTO list_tour(namapaket, tujuan, hargapaket, tarifperorang, minorang) VALUES (?,?,?,?,?)";
    //final String delete = "DELETE FROM list_tour WHERE idtour=?";
    //final String update = "UPDATE list_tour SET namapaket=?,tujuan=?,hargapaket=?,tarifperorang=?,minorang=? WHERE idtour=?";
    //final String select = "SELECT * FROM transaksi_tour";
    //final String carinama = "SELECT * FROM list_tour WHERE nama_lengkap like ?";
    /*
    public DAO_RiwayatPeminjaman() {
     //   connection = Controller_DB.getKoneksi();
    }

    public List<Peminjaman> getAll() {
        List<Peminjaman>lmm=null;
        
        try {
            lmm = new ArrayList<>();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while(rs.next()) {
                Peminjaman mm = new Peminjaman();
                mm.setNominalPinjam(rs.getString("nominalpinjam"));
                mm.setNominalPinjam(rs.getInt("idinvoicetour"));
                mm.setNamaPelanggan(rs.getString("namapelanggan"));
                mm.setPaketlayanan(rs.getString("namapaket"));
                mm.setTujuantour(rs.getString("tujuan"));
                mm.setHarga(rs.getInt("hargapaket"));
                mm.setTarifperorgtour(rs.getInt("tarifperorang"));
                mm.setTambahanorng(rs.getInt("tambahanorang"));
                mm.setWaktu(rs.getString("waktu"));
                mm.setTanggal(rs.getString("tanggal"));
                mm.setTotal(rs.getInt("totalharga"));
                lmm.add(mm);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return lmm;
    }
}*/
