/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package briku;

public class KepalaCabang extends Nasabah {
    int idKelapaCabang;
    String namaKepalaCabang;
    int idNasabah;
    String Pencairan;

    public void setIdKelapaCabang(int idKelapaCabang) {
        this.idKelapaCabang = idKelapaCabang;
    }

    public void setNamaKepalaCabang(String namaKepalaCabang) {
        this.namaKepalaCabang = namaKepalaCabang;
    }

    @Override
    public void setIdNasabah(int idNasabah) {
        this.idNasabah = idNasabah;
    }

    public void setPencairan(String Pencairan) {
        this.Pencairan = Pencairan;
    }

    public int getIdKelapaCabang() {
        return idKelapaCabang;
    }

    public String getNamaKepalaCabang() {
        return namaKepalaCabang;
    }

    @Override
    public int getIdNasabah() {
        return idNasabah;
    }

    public String getPencairan() {
        return Pencairan;
    }
    
}
