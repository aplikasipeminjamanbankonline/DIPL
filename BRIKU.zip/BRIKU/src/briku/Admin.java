/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package briku;


public class Admin extends Nasabah {
    private int idAdmin;
    private String namaAdmin;
    private int idNasabah;

    public void setIdAdmin(int idAdmin) {
        this.idAdmin = idAdmin;
    }

    public void setNamaAdmin(String namaAdmin) {
        this.namaAdmin = namaAdmin;
    }

    @Override
    public void setIdNasabah(int idNasabah) {
        this.idNasabah = idNasabah;
    }

    public int getIdAdmin() {
        return idAdmin;
    }

    public String getNamaAdmin() {
        return namaAdmin;
    }

    @Override
    public int getIdNasabah() {
        return idNasabah;
    }
    
}
